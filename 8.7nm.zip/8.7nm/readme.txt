1.atomsk --polycrystal Alfcc.xsf polycrystal2.txt Alfccpolycrystal.cfg 
2..cfg换成.data
3.atomsk Alfccpolycrystal.cfg lammps fcc.data
4.打开fcc.data.lmp  修改：原子类型 添加摩尔质量   
5.in.fcc文件原子替换    fccset.lmp
6.将 fccset.lmp进行mc交换原子
7.将mc.data进行拉伸20%。