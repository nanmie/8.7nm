units           metal              #模拟单位，金属
boundary        p p p          	#边界条件，三个方向都为周期性边界条件
atom_style      atomic          #原子类型

read_data       fccset.lmp      #读入模型

#定义原子间相互作用势
pair_style     eam/alloy           #势函数类型
pair_coeff     * * AlCoCuFeNi.eam Al Co Cu Fe Ni  

neighbor        1 bin             #近邻数表，意思是每个原子在所取对势（即pair style）的截断半径以外，计算机还会在1 bin的额外范围每一时间步检测其原子间的相互作用力。
neigh_modify  delay 1 check yes             #延迟一步更新  检查是否移出邻居数表范围，保障力计算的准确性

timestep        0.005         #模拟步长，单位ps，1ps=1e-12s   0.005ps
variable        N equal step      #定义变量，步数

## define computes
compute       myTemp all temp                #计算所有原子的温度
compute       disp all displace/atom          #计算所有原子的位移
compute         pot all pe/atom                   # 计算每个原子的势能
compute         ke all ke/atom                    # 计算每个原子的动能
compute       s all stress/atom NULL          #计算每个原子的应力
compute       press  all pressure thermo_temp       # 计算应力，计算结果记为p
compute       coord all coord/atom cutoff 3.0   

#热力学输出
log               mc.log
thermo			10000                #每一千步输出一次热力学信息
thermo_style	custom step temp pe ke  etotal press vol       #输出类型 输出步数、温度、势能  动能  总能量

# 能量曲线专用文件：energy_mc.txt
variable stepv    equal step
variable tempv    equal temp
variable pev      equal pe
variable kev      equal ke
variable etv      equal etotal
variable prv      equal press
fix     F_EN      all print 10000  "${stepv} ${tempv} ${pev} ${kev} ${etv} ${prv}"  file energy_mc.txt screen no title "step temp pe ke etotal press"

#温度初始化
velocity   all create 300 8898900         #为所有原子生成初始速度，目标温度为300 K，随机数种子为8898900。


# step 3: MC	(eq20)  
	fix             MC1 all atom/swap 1 1 8898900 300 ke no types 1 2
	run             30000
	unfix           MC1

	fix             MC2 all atom/swap 1 1 8898900 300 ke no types 1 3
	run             30000
	unfix           MC2

	fix             MC3 all atom/swap 1 1 8898900 300 ke no types 1 4
	run             30000
	unfix           MC3

	fix             MC4 all atom/swap 1 1 8898900 300 ke no types 1 5
	run             30000
	unfix           MC4

	fix             MC5 all atom/swap 1 1 8898900 300 ke no types 2 3
	run             30000
	unfix           MC5

	fix             MC6 all atom/swap 1 1 8898900 300 ke no types 2 4 
	run             30000
	unfix           MC6

	fix             MC7 all atom/swap 1 1 8898900 300 ke no types 2 5
	run             30000
	unfix           MC7

	fix             MC8 all atom/swap 1 1 8898900 300 ke no types 3 4
	run             30000
	unfix           MC8

	fix             MC9 all atom/swap 1 1 8898900 300 ke no types 3 5 
	run             30000
	unfix           MC9

	fix             MC10 all atom/swap 1 1 8898900 300 ke no types 4 5
	run             30000
	unfix           MC10

unfix	F_EN
reset_timestep 0

write_data     mc.data
write_restart mc.restart
